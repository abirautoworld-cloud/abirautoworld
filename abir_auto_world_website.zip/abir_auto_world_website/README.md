# Abir Auto World website

This is a responsive one-page static website.

## Preview locally
Open `index.html` in a web browser.

## Before publishing
1. Confirm the business address and add the exact Google Maps pin if available.
2. Confirm that both phone numbers are WhatsApp-enabled.
3. Replace the two sample car cards with current inventory, real photos, and the direct OLX listing URLs.
4. Confirm which documentation services are actually offered. The site describes documentation as assistance/guidance and notes that statutory approval is handled by the relevant authorities.
5. Check prices, mileage, ownership and availability before publishing.

## Publish free with GitHub Pages
1. Sign in to https://github.com/ or create an account.
2. Click **New repository**.
3. Name it `abir-auto-world` and set it to **Public**.
4. Create the repository.
5. Click **Add file → Upload files** and upload `index.html` (and this README if you like).
6. Click **Commit changes**.
7. Open **Settings → Pages**.
8. Under **Build and deployment**, choose **Deploy from a branch**.
9. Select branch **main** and folder **/(root)**, then click **Save**.
10. Wait a few minutes. GitHub will show your website URL, usually:
   `https://YOUR-GITHUB-USERNAME.github.io/abir-auto-world/`

To update the website later, open the repository, upload/replace `index.html`, and commit the changes. GitHub Pages will publish the update automatically.

## Optional custom domain
You can buy a domain separately, then configure it in **Settings → Pages → Custom domain** and follow GitHub's DNS instructions.
